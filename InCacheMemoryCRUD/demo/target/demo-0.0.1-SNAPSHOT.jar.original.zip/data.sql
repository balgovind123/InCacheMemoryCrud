insert into Product
values(10001,'Bat', 'E1234567');

insert into Product
values(10002,'Ball', 'A1234568');